import java.util.Scanner;

public class MainProgram {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita al usuario ingresar una cadena de caracteres.
        System.out.print("Ingresa una cadena de caracteres: ");
        String lectTeclado = scanner.nextLine();

        try {
            // Llama al método caracterEn de la clase CaracterEnExample para obtener el carácter en la posición 7.
            char resultado = CaracterEnExample.caracterEn(lectTeclado, 7);
            System.out.println("El carácter en la posición 7 es: " + resultado);
        } catch (Exception e) {
            // Si ocurre una excepción (posición fuera de rango), se muestra un mensaje de error.
            System.out.println("Has intentado recuperar una posición de la cadena de caracteres que no existe.");
        }
    }
}
