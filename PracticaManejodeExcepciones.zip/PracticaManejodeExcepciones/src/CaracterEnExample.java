public class CaracterEnExample {

    // Este método recibe una cadena y una posición, y devuelve el carácter en la posición indicada.
    // Si la posición está dentro de los límites de la cadena, se retorna el carácter en esa posición.
    // Si la posición está fuera de rango, se lanza una excepción.
    public static char caracterEn(String cadena, int posicion) throws Exception {
        if (posicion >= 0 && posicion < cadena.length()) {
            return cadena.charAt(posicion);
        } else {
            throw new Exception("Posición fuera de rango");
        }
    }

    public static void main(String[] args) {
        String cadena = "Hola, mundo!";
        int posicion = 5;

        try {
            // Se llama al método caracterEn pasando la cadena y la posición indicada.
            // Si la posición está dentro de los límites, se imprime el carácter en esa posición.
            char resultado = caracterEn(cadena, posicion);
            System.out.println("El carácter en la posición " + posicion + " es: " + resultado);
        } catch (Exception e) {
            // Si ocurre una excepción (debido a una posición fuera de rango), se imprime un mensaje de error.
            System.out.println("Error: " + e.getMessage());
        }
    }
}
