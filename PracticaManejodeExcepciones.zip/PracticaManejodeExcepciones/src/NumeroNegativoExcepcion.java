import java.util.Scanner;

// Definición de la clase de excepción personalizada
public class NumeroNegativoExcepcion extends Exception {
    public NumeroNegativoExcepcion() {
        super();
    }

    public NumeroNegativoExcepcion(String mensaje) {
        super(mensaje);
    }
}

    class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Solicita al usuario ingresar un valor numérico
            System.out.print("Ingresa un valor numérico: ");
            double valor = scanner.nextDouble();

            if (valor < 0) {
                // Lanza una excepción personalizada si se ingresa un número negativo
                throw new NumeroNegativoExcepcion("Número negativo ingresado");
            }

            double raizCuadrada = Math.sqrt(valor);
            System.out.println("La raíz cuadrada del valor es: " + raizCuadrada);
        } catch (NumeroNegativoExcepcion e) {
            // Captura y muestra el mensaje de la excepción personalizada
            System.out.println("Excepción: " + e.getMessage());
        } catch (java.util.InputMismatchException e) {
            // Captura y muestra un mensaje si se ingresa un valor no numérico
            System.out.println("Ingresa un valor numérico válido.");
        }
    }
}
